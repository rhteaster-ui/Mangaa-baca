"use client";
import Link from "next/link";
import { useState, useRef, useEffect } from "react";
import { useRouter } from "next/navigation";

// Translate languages list
const LANGUAGES = [
  { code: "id", name: "Indonesia" },
  { code: "en", name: "English" },
  { code: "ja", name: "日本語" },
  { code: "zh-CN", name: "简体中文" },
  { code: "zh-TW", name: "繁體中文" },
  { code: "ko", name: "한국어" },
  { code: "es", name: "Español" },
  { code: "fr", name: "Français" },
  { code: "de", name: "Deutsch" },
  { code: "pt", name: "Português" },
  { code: "ru", name: "Русский" },
  { code: "ar", name: "العربية" },
  { code: "th", name: "ไทย" },
  { code: "vi", name: "Tiếng Việt" },
];

function TranslateInline() {
  const [open, setOpen] = useState(false);
  const [selected, setSelected] = useState("id");
  const dropRef = useRef(null);

  useEffect(() => {
    window.googleTranslateElementInit = () => {
      try {
        new window.google.translate.TranslateElement(
          { pageLanguage: "auto", autoDisplay: false },
          "gte_navbar"
        );
      } catch {}
    };
    if (!document.querySelector("#gte-script")) {
      const s = document.createElement("script");
      s.id = "gte-script";
      s.src = "//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit";
      s.async = true;
      document.head.appendChild(s);
    }
  }, []);

  useEffect(() => {
    function handleOutside(e) {
      if (dropRef.current && !dropRef.current.contains(e.target)) setOpen(false);
    }
    if (open) document.addEventListener("mousedown", handleOutside);
    return () => document.removeEventListener("mousedown", handleOutside);
  }, [open]);

  function selectLang(code) {
    setSelected(code);
    setOpen(false);
    const sel = document.querySelector(".goog-te-combo");
    if (sel) { sel.value = code; sel.dispatchEvent(new Event("change")); }
  }

  const currentLabel = LANGUAGES.find(l => l.code === selected)?.name || "ID";

  return (
    <div ref={dropRef} style={{ position: "relative" }}>
      <button
        onClick={() => setOpen(v => !v)}
        style={{
          display: "flex", alignItems: "center", gap: 4,
          padding: "6px 10px", borderRadius: 10,
          background: open ? "rgba(245,158,11,0.12)" : "rgba(255,255,255,0.05)",
          border: open ? "1px solid rgba(245,158,11,0.35)" : "1px solid rgba(255,255,255,0.07)",
          color: open ? "#f59e0b" : "#9ca3af", cursor: "pointer", transition: "all 0.15s",
        }}
        aria-label="Translate"
      >
        {/* Globe SVG */}
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
          <circle cx="12" cy="12" r="10"/>
          <line x1="2" y1="12" x2="22" y2="12"/>
          <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>
        </svg>
        <span style={{ fontSize: 11, fontWeight: 600 }}>{currentLabel}</span>
        <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" style={{ transform: open ? "rotate(180deg)" : "none", transition: "transform 0.15s" }}>
          <path d="m6 9 6 6 6-6"/>
        </svg>
      </button>

      {open && (
        <div style={{
          position: "absolute", top: "calc(100% + 6px)", right: 0,
          background: "#0d1018", border: "1px solid rgba(255,255,255,0.1)",
          borderRadius: 12, padding: "6px 0", zIndex: 999,
          minWidth: 150, maxHeight: 260, overflowY: "auto",
          boxShadow: "0 8px 32px rgba(0,0,0,0.6)",
          scrollbarWidth: "none",
        }}>
          {LANGUAGES.map(l => (
            <button
              key={l.code}
              onClick={() => selectLang(l.code)}
              style={{
                width: "100%", padding: "9px 14px", textAlign: "left",
                fontSize: 12, background: selected === l.code ? "rgba(245,158,11,0.12)" : "transparent",
                color: selected === l.code ? "#f59e0b" : "#9ca3af",
                border: "none", cursor: "pointer",
                borderLeft: selected === l.code ? "2px solid #f59e0b" : "2px solid transparent",
              }}
            >
              {l.name}
            </button>
          ))}
        </div>
      )}
      <div id="gte_navbar" style={{ display: "none" }} />
    </div>
  );
}

export default function Navbar() {
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchVal, setSearchVal] = useState("");
  const router = useRouter();
  const inputRef = useRef(null);

  useEffect(() => {
    if (searchOpen && inputRef.current) inputRef.current.focus();
  }, [searchOpen]);

  function handleSearch(e) {
    e.preventDefault();
    if (!searchVal.trim()) return;
    router.push(`/search?q=${encodeURIComponent(searchVal.trim())}`);
    setSearchVal("");
    setSearchOpen(false);
  }

  return (
    <>
      <style>{`
        .goog-te-banner-frame.skiptranslate { display: none !important; }
        body { top: 0px !important; }
        .goog-te-combo, .goog-te-gadget-simple, .goog-te-gadget span { display: none !important; }
        .goog-te-gadget { color: transparent !important; font-size: 0 !important; }
      `}</style>

      <header
        style={{
          position: "sticky", top: 0, zIndex: 100,
          background: "rgba(8,10,15,0.95)", backdropFilter: "blur(20px)",
          WebkitBackdropFilter: "blur(20px)", borderBottom: "1px solid rgba(255,255,255,0.06)",
        }}
      >
        <div style={{ maxWidth: 900, margin: "0 auto", display: "flex", alignItems: "center", gap: 8, padding: "0 14px", height: 56 }}>

          {/* Brand */}
          <Link href="/" style={{ display: "flex", alignItems: "center", gap: 4, flexShrink: 0, textDecoration: "none", marginRight: 6 }}>
            <div style={{
              width: 32, height: 32, borderRadius: 8, overflow: "hidden", flexShrink: 0,
              background: "#000", display: "flex", alignItems: "center", justifyContent: "center",
            }}>
              <img src="/icon.png" alt="M" style={{ width: 28, height: 28, objectFit: "contain" }} />
            </div>
            <span style={{
              fontSize: 17, fontWeight: 800, letterSpacing: "-0.5px",
              background: "linear-gradient(135deg,#f59e0b,#fbbf24)",
              WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
            }}>
              angarift
            </span>
          </Link>

          {/* Desktop nav */}
          <nav style={{ display: "none", alignItems: "center", gap: 2, marginRight: 8 }} className="hidden md:flex">
            {[{ href: "/", l: "Home" }, { href: "/search", l: "Jelajah" }, { href: "/library", l: "Library" }, { href: "/about", l: "About" }].map(({ href, l }) => (
              <Link key={href} href={href} style={{ fontSize: 13, color: "#6b7280", padding: "6px 12px", borderRadius: 8, textDecoration: "none" }}>{l}</Link>
            ))}
          </nav>

          <div style={{ flex: 1 }} />

          {/* Right icons area */}
          <div style={{ display: "flex", alignItems: "center", gap: 6 }}>

            {/* Translate */}
            <TranslateInline />

            {/* Search expandable */}
            <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
              {searchOpen && (
                <form onSubmit={handleSearch} style={{ display: "flex", alignItems: "center" }}>
                  <div style={{ position: "relative" }}>
                    <svg style={{ position: "absolute", left: 10, top: "50%", transform: "translateY(-50%)" }} width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#6b7280" strokeWidth="2.5" strokeLinecap="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
                    <input
                      ref={inputRef}
                      value={searchVal}
                      onChange={e => setSearchVal(e.target.value)}
                      placeholder="Cari manga..."
                      style={{
                        fontSize: 13, paddingLeft: 32, paddingRight: 12, paddingTop: 8, paddingBottom: 8,
                        borderRadius: 12, outline: "none", width: 170, color: "#e5e7eb",
                        background: "rgba(255,255,255,0.06)", border: "1px solid rgba(245,158,11,0.35)",
                      }}
                    />
                  </div>
                </form>
              )}

              <button
                onClick={() => {
                  if (searchOpen && searchVal.trim()) {
                    router.push(`/search?q=${encodeURIComponent(searchVal.trim())}`);
                    setSearchVal(""); setSearchOpen(false);
                  } else {
                    setSearchOpen(v => !v);
                    if (searchOpen) setSearchVal("");
                  }
                }}
                style={{
                  width: 36, height: 36, borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center",
                  cursor: "pointer", flexShrink: 0, transition: "all 0.15s",
                  background: searchOpen ? "rgba(245,158,11,0.12)" : "rgba(255,255,255,0.05)",
                  border: searchOpen ? "1px solid rgba(245,158,11,0.35)" : "1px solid rgba(255,255,255,0.07)",
                }}
                aria-label="Search"
              >
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke={searchOpen ? "#f59e0b" : "#9ca3af"} strokeWidth="2.5" strokeLinecap="round">
                  <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
                </svg>
              </button>

              {searchOpen && (
                <button
                  onClick={() => { setSearchOpen(false); setSearchVal(""); }}
                  style={{ width: 28, height: 28, borderRadius: 8, display: "flex", alignItems: "center", justifyContent: "center", background: "transparent", border: "none", cursor: "pointer", color: "#6b7280" }}
                >
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg>
                </button>
              )}
            </div>
          </div>
        </div>
      </header>
    </>
  );
}
