"use client";
import { useState, useRef, useEffect, useCallback } from "react";
import { usePathname } from "next/navigation";

function formatTime(s) {
  if (!s || isNaN(s)) return "0:00";
  const m = Math.floor(s / 60);
  const sec = Math.floor(s % 60);
  return `${m}:${sec.toString().padStart(2, "0")}`;
}

export default function MusicPlayer() {
  const pathname = usePathname();
  const [isOpen, setIsOpen] = useState(false);
  const [searchInput, setSearchInput] = useState("");
  const [track, setTrack] = useState(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const [searching, setSearching] = useState(false);
  const [pos, setPos] = useState(null);
  const audioRef = useRef(null);
  const btnRef = useRef(null);
  const drag = useRef({ active: false, moved: false, sx: 0, sy: 0, bx: 0, by: 0 });

  const hide = pathname === "/about" || pathname?.startsWith("/search");

  const doSearch = useCallback(async (q) => {
    setSearching(true);
    try {
      const res = await fetch(`/api/music?q=${encodeURIComponent(q)}`);
      const data = await res.json();
      if (data.status && data.result) {
        setTrack(data.result);
      }
    } catch (e) {
      console.error("music err", e);
    } finally {
      setSearching(false);
    }
  }, []);

  // Initial load
  useEffect(() => { doSearch("Inni uhibbuka"); }, [doSearch]);

  // Audio events
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    const onTime = () => {
      const dur = audio.duration || track?.duration || 1;
      setCurrentTime(audio.currentTime);
      setProgress(audio.currentTime / dur);
    };
    const onEnded = () => { setIsPlaying(false); setProgress(0); setCurrentTime(0); };
    audio.addEventListener("timeupdate", onTime);
    audio.addEventListener("ended", onEnded);
    return () => {
      audio.removeEventListener("timeupdate", onTime);
      audio.removeEventListener("ended", onEnded);
    };
  }, [track]);

  // Load track
  useEffect(() => {
    if (!track?.mp3 || !audioRef.current) return;
    const audio = audioRef.current;
    audio.pause();
    audio.src = track.mp3;
    audio.load();
    setProgress(0);
    setCurrentTime(0);
    setIsPlaying(false);
  }, [track]);

  if (hide) return null;

  function togglePlay() {
    const audio = audioRef.current;
    if (!audio || !track?.mp3) return;
    if (isPlaying) {
      audio.pause();
      setIsPlaying(false);
    } else {
      audio.play().then(() => setIsPlaying(true)).catch((e) => console.error(e));
    }
  }

  // Drag handlers
  function onTouchStart(e) {
    const t = e.touches[0];
    const rect = btnRef.current?.getBoundingClientRect();
    drag.current = {
      active: true, moved: false,
      sx: t.clientX, sy: t.clientY,
      bx: pos?.x ?? (window.innerWidth - (rect?.width || 54) - 16),
      by: pos?.y ?? (window.innerHeight - (rect?.height || 54) - 80),
    };
  }
  function onTouchMove(e) {
    if (!drag.current.active) return;
    e.preventDefault();
    const t = e.touches[0];
    const dx = t.clientX - drag.current.sx;
    const dy = t.clientY - drag.current.sy;
    if (Math.hypot(dx, dy) > 8) {
      drag.current.moved = true;
      setPos({
        x: Math.max(4, Math.min(window.innerWidth - 60, drag.current.bx + dx)),
        y: Math.max(4, Math.min(window.innerHeight - 100, drag.current.by + dy)),
      });
    }
  }
  function onTouchEnd() {
    if (!drag.current.moved) setIsOpen(true);
    drag.current.active = false;
    drag.current.moved = false;
  }

  const R = 23, C = 2 * Math.PI * R;
  const btnStyle = pos
    ? { position: "fixed", left: pos.x, top: pos.y, bottom: "auto", right: "auto", zIndex: 290 }
    : { position: "fixed", right: 16, bottom: 76, zIndex: 290 };

  return (
    <>
      <audio ref={audioRef} preload="metadata" crossOrigin="anonymous" />

      {/* Floating Button */}
      <div ref={btnRef} style={btnStyle} onTouchStart={onTouchStart} onTouchMove={onTouchMove} onTouchEnd={onTouchEnd}>
        <button
          onClick={() => setIsOpen(true)}
          style={{ width: 54, height: 54, borderRadius: "50%", background: "rgba(8,10,15,0.92)", boxShadow: "0 6px 24px rgba(0,0,0,0.5), 0 0 0 1px rgba(245,158,11,0.25)", position: "relative", display: "flex", alignItems: "center", justifyContent: "center" }}
          aria-label="Music Player"
        >
          <svg style={{ position: "absolute", inset: 0, transform: "rotate(-90deg)" }} width="54" height="54" viewBox="0 0 54 54">
            <circle cx="27" cy="27" r={R} fill="none" stroke="rgba(255,255,255,0.07)" strokeWidth="3" />
            <circle cx="27" cy="27" r={R} fill="none" stroke={isPlaying ? "#f59e0b" : "rgba(245,158,11,0.4)"} strokeWidth="3" strokeLinecap="round"
              strokeDasharray={C} strokeDashoffset={C * (1 - progress)} style={{ transition: "stroke-dashoffset 0.25s linear" }} />
          </svg>
          {track?.thumbnail
            ? <img src={track.thumbnail} alt="" style={{ width: 32, height: 32, borderRadius: "50%", objectFit: "cover" }} />
            : <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#f59e0b" strokeWidth="1.8" strokeLinecap="round"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>
          }
          {isPlaying && (
            <span style={{ position: "absolute", top: -2, right: -2, width: 12, height: 12, borderRadius: "50%", background: "#f59e0b", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <span style={{ width: 6, height: 6, borderRadius: "50%", background: "white", animation: "pulse 1.5s infinite" }} />
            </span>
          )}
        </button>
      </div>

      {/* Player Panel */}
      {isOpen && (
        <div
          style={{ position: "fixed", inset: 0, zIndex: 400, display: "flex", alignItems: "flex-end", justifyContent: "center", background: "rgba(0,0,0,0.6)", backdropFilter: "blur(4px)" }}
          onClick={(e) => { if (e.target === e.currentTarget) setIsOpen(false); }}
        >
          <div style={{ width: "100%", maxWidth: 400, margin: "0 16px 80px", borderRadius: 28, overflow: "hidden", background: "#0d0f17", border: "1px solid rgba(255,255,255,0.07)", boxShadow: "0 -20px 60px rgba(0,0,0,0.5)" }}>
            {/* Handle */}
            <div style={{ display: "flex", justifyContent: "center", padding: "12px 0 4px" }}>
              <div style={{ width: 40, height: 4, borderRadius: 2, background: "rgba(255,255,255,0.12)" }} />
            </div>

            {/* Now Playing */}
            {track ? (
              <div style={{ padding: "12px 20px 20px", display: "flex", flexDirection: "column", alignItems: "center" }}>
                <img
                  src={track.thumbnail}
                  alt={track.title}
                  style={{ width: 120, height: 120, borderRadius: 16, objectFit: "cover", marginBottom: 16, boxShadow: "0 8px 32px rgba(0,0,0,0.5)", border: "1px solid rgba(245,158,11,0.2)" }}
                />
                <p style={{ fontSize: 14, fontWeight: 700, color: "white", textAlign: "center", margin: "0 0 4px", overflow: "hidden", display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", width: "100%" }}>{track.title}</p>
                <p style={{ fontSize: 12, color: "#9ca3af", marginBottom: 4 }}>{track.author}</p>
                <p style={{ fontSize: 11, color: "#6b7280", marginBottom: 16 }}>{track.views?.toLocaleString()} views · {track.published}</p>

                {/* Progress */}
                <div style={{ width: "100%", marginBottom: 8 }}>
                  <div style={{ height: 4, borderRadius: 2, background: "rgba(255,255,255,0.08)", overflow: "hidden" }}>
                    <div style={{ height: "100%", background: "linear-gradient(to right,#f59e0b,#ef4444)", borderRadius: 2, width: `${progress * 100}%`, transition: "width 0.25s linear" }} />
                  </div>
                  <div style={{ display: "flex", justifyContent: "space-between", marginTop: 4 }}>
                    <span style={{ fontSize: 10, color: "#6b7280" }}>{formatTime(currentTime)}</span>
                    <span style={{ fontSize: 10, color: "#6b7280" }}>{track.duration_timestamp || formatTime(track.duration)}</span>
                  </div>
                </div>

                {/* Play/Pause */}
                <button
                  onClick={togglePlay}
                  disabled={searching}
                  style={{ width: 52, height: 52, borderRadius: "50%", background: "linear-gradient(135deg,#f59e0b,#ef4444)", border: "none", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", boxShadow: "0 4px 20px rgba(245,158,11,0.4)", marginTop: 4, transition: "transform 0.15s", opacity: searching ? 0.5 : 1 }}
                  onTouchStart={e => e.currentTarget.style.transform = "scale(0.93)"}
                  onTouchEnd={e => e.currentTarget.style.transform = "scale(1)"}
                >
                  {isPlaying
                    ? <svg width="18" height="18" viewBox="0 0 24 24" fill="white"><rect x="6" y="4" width="4" height="16" rx="1"/><rect x="14" y="4" width="4" height="16" rx="1"/></svg>
                    : <svg width="18" height="18" viewBox="0 0 24 24" fill="white"><polygon points="5,3 19,12 5,21"/></svg>
                  }
                </button>
              </div>
            ) : (
              <div style={{ padding: "40px 20px", textAlign: "center" }}>
                {searching
                  ? <div style={{ width: 32, height: 32, border: "2px solid #f59e0b", borderTopColor: "transparent", borderRadius: "50%", animation: "spin 0.8s linear infinite", margin: "0 auto 12px" }} />
                  : <svg style={{ margin: "0 auto 12px", display: "block" }} width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#4b5563" strokeWidth="1.5" strokeLinecap="round"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>
                }
                <p style={{ fontSize: 13, color: "#6b7280" }}>{searching ? "Mencari lagu..." : "Tidak ada lagu"}</p>
              </div>
            )}

            {/* Search */}
            <div style={{ padding: "0 16px 12px", borderTop: "1px solid rgba(255,255,255,0.06)" }}>
              <form onSubmit={(e) => { e.preventDefault(); if (searchInput.trim()) doSearch(searchInput); }} style={{ display: "flex", gap: 8, marginTop: 12 }}>
                <div style={{ position: "relative", flex: 1 }}>
                  <svg style={{ position: "absolute", left: 10, top: "50%", transform: "translateY(-50%)" }} width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#6b7280" strokeWidth="2.5" strokeLinecap="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
                  <input
                    value={searchInput}
                    onChange={e => setSearchInput(e.target.value)}
                    placeholder="Cari lagu..."
                    style={{ width: "100%", fontSize: 13, paddingLeft: 32, paddingRight: 12, paddingTop: 8, paddingBottom: 8, borderRadius: 12, background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.08)", color: "#e5e7eb", outline: "none", boxSizing: "border-box" }}
                  />
                </div>
                <button
                  type="submit"
                  disabled={searching}
                  style={{ padding: "8px 14px", borderRadius: 12, background: "linear-gradient(135deg,#f59e0b,#ef4444)", color: "white", fontSize: 12, fontWeight: 600, border: "none", cursor: "pointer", flexShrink: 0, opacity: searching ? 0.6 : 1 }}
                >
                  {searching ? "..." : "Cari"}
                </button>
              </form>
            </div>

            {/* YouTube link */}
            {track?.url && (
              <div style={{ padding: "0 16px 12px" }}>
                <a
                  href={track.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  style={{ display: "flex", alignItems: "center", gap: 8, padding: "8px 12px", borderRadius: 10, background: "rgba(255,0,0,0.08)", border: "1px solid rgba(255,0,0,0.15)", textDecoration: "none", color: "#fc8181", fontSize: 11 }}
                >
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="#fc8181"><path d="M23.495 6.205a3.007 3.007 0 0 0-2.088-2.088c-1.87-.501-9.396-.501-9.396-.501s-7.507-.01-9.396.501A3.007 3.007 0 0 0 .527 6.205a31.247 31.247 0 0 0-.522 5.805 31.247 31.247 0 0 0 .522 5.783 3.007 3.007 0 0 0 2.088 2.088c1.868.502 9.396.502 9.396.502s7.506 0 9.396-.502a3.007 3.007 0 0 0 2.088-2.088 31.247 31.247 0 0 0 .5-5.783 31.247 31.247 0 0 0-.5-5.805zM9.609 15.601V8.408l6.264 3.602z"/></svg>
                  Lihat di YouTube
                </a>
              </div>
            )}

            {/* Close */}
            <button
              onClick={() => setIsOpen(false)}
              style={{ width: "100%", padding: "12px", fontSize: 12, color: "#4b5563", background: "transparent", border: "none", borderTop: "1px solid rgba(255,255,255,0.06)", cursor: "pointer" }}
            >
              Tutup
            </button>
          </div>
        </div>
      )}

      <style>{`
        @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.4} }
        @keyframes spin { to{transform:rotate(360deg)} }
      `}</style>
    </>
  );
}
