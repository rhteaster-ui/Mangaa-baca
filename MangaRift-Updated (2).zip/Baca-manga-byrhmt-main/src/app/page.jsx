"use client";
import { useState, useEffect, useRef } from "react";
import MangaCard from "@/components/manga-card";
import Link from "next/link";

const MDEX = "https://api.mangadex.org";

async function fetchManga(sort, limit = 18) {
  const p = new URLSearchParams();
  p.append("limit", limit);
  p.append("includes[]", "cover_art");
  p.append("availableTranslatedLanguage[]", "en");
  p.append("contentRating[]", "safe");
  p.append("contentRating[]", "suggestive");
  p.append(`order[${sort}]`, "desc");
  const res = await fetch(`${MDEX}/manga?${p}`, { headers: { "User-Agent": "MangaRift/1.0" }, next: { revalidate: 300 } });
  const data = await res.json();
  return data.data || [];
}

function getTitle(m) {
  const t = m?.attributes?.title || {};
  return t.en || t["ja-ro"] || t.ja || Object.values(t)[0] || "";
}

function getCover(m) {
  const rel = m?.relationships?.find(r => r.type === "cover_art");
  const f = rel?.attributes?.fileName;
  if (!f) return null;
  return `/api/proxy/cover?url=${encodeURIComponent(`https://uploads.mangadex.org/covers/${m.id}/${f}.512.jpg`)}`;
}

function getDesc(m) {
  return m?.attributes?.description?.en || Object.values(m?.attributes?.description || {})[0] || "";
}

// Auto-sliding Hero Carousel
function HeroCarousel({ items }) {
  const [active, setActive] = useState(0);
  const timerRef = useRef(null);

  useEffect(() => {
    timerRef.current = setInterval(() => {
      setActive(prev => (prev + 1) % items.length);
    }, 4000);
    return () => clearInterval(timerRef.current);
  }, [items.length]);

  function goTo(i) {
    clearInterval(timerRef.current);
    setActive(i);
    timerRef.current = setInterval(() => setActive(prev => (prev + 1) % items.length), 4000);
  }

  const m = items[active];
  if (!m) return null;
  const title = getTitle(m);
  const cover = getCover(m);
  const desc = getDesc(m);

  return (
    <div style={{ position: "relative", width: "100%", height: 340, overflow: "hidden" }}>
      {/* BG blur */}
      {cover && (
        <img
          src={cover}
          alt=""
          style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover", filter: "blur(4px) brightness(0.28)", transform: "scale(1.08)", transition: "opacity 0.5s" }}
        />
      )}
      <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to top,#080a0f 28%,transparent 70%)" }} />

      {/* Content */}
      <div style={{ position: "relative", zIndex: 10, display: "flex", alignItems: "flex-end", height: "100%", padding: "0 20px 28px", maxWidth: 640, margin: "0 auto", gap: 16 }}>
        {cover && (
          <Link href={`/manga/${m.id}`} style={{ flexShrink: 0 }}>
            <img src={cover} alt={title} style={{ width: 90, borderRadius: 12, objectFit: "cover", aspectRatio: "2/3", border: "2px solid rgba(245,158,11,0.5)", boxShadow: "0 16px 40px rgba(0,0,0,0.5)", transition: "transform 0.3s" }} />
          </Link>
        )}
        <div style={{ flex: 1, minWidth: 0 }}>
          <span style={{ display: "inline-block", fontSize: 10, fontWeight: 700, padding: "3px 10px", borderRadius: 20, background: "rgba(245,158,11,0.85)", color: "white", marginBottom: 8 }}>
            Top Rated #{active + 1}
          </span>
          <h1 style={{ fontSize: 19, fontWeight: 800, color: "white", margin: "0 0 6px", overflow: "hidden", display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", lineHeight: 1.3 }}>{title}</h1>
          <p style={{ fontSize: 12, color: "#9ca3af", margin: "0 0 14px", overflow: "hidden", display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", lineHeight: 1.5 }}>{desc}</p>
          <Link href={`/manga/${m.id}`} style={{
            display: "inline-flex", alignItems: "center", gap: 6,
            fontSize: 13, fontWeight: 700, padding: "10px 18px", borderRadius: 12,
            background: "linear-gradient(135deg,#f59e0b,#ef4444)", color: "white", textDecoration: "none",
          }}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>
            Baca Sekarang
          </Link>
        </div>
      </div>

      {/* Dots */}
      <div style={{ position: "absolute", bottom: 10, left: "50%", transform: "translateX(-50%)", display: "flex", gap: 6, zIndex: 10 }}>
        {items.map((_, i) => (
          <button
            key={i}
            onClick={() => goTo(i)}
            style={{
              width: active === i ? 20 : 6, height: 6, borderRadius: 3, border: "none", cursor: "pointer", transition: "all 0.3s",
              background: active === i ? "#f59e0b" : "rgba(255,255,255,0.3)",
            }}
          />
        ))}
      </div>
    </div>
  );
}

export default function HomePage() {
  const [latest, setLatest] = useState([]);
  const [popular, setPopular] = useState([]);
  const [topRated, setTopRated] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      try {
        const [l, p, t] = await Promise.all([
          fetchManga("latestUploadedChapter", 18),
          fetchManga("followedCount", 12),
          fetchManga("rating", 5),
        ]);
        setLatest(l);
        setPopular(p);
        setTopRated(t);
      } catch (e) { console.error(e); }
      finally { setLoading(false); }
    }
    load();
  }, []);

  if (loading) return (
    <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: "60vh", flexDirection: "column", gap: 16 }}>
      <div style={{ width: 36, height: 36, border: "3px solid #f59e0b", borderTopColor: "transparent", borderRadius: "50%", animation: "spin 0.8s linear infinite" }} />
      <p style={{ fontSize: 13, color: "#6b7280" }}>Memuat manga...</p>
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
    </div>
  );

  return (
    <div>
      {/* Auto-Slide Hero Carousel */}
      {topRated.length > 0 && <HeroCarousel items={topRated.slice(0, 5)} />}

      <div style={{ maxWidth: 900, margin: "0 auto", padding: "16px 16px 16px" }}>
        {/* Filter chips */}
        <div style={{ display: "flex", gap: 8, overflowX: "auto", paddingBottom: 4, marginBottom: 24, scrollbarWidth: "none" }}>
          {[
            { label: "Terbaru", href: "/search?sort=latestUploadedChapter" },
            { label: "Populer", href: "/search?sort=followedCount" },
            { label: "Rating Tinggi", href: "/search?sort=rating" },
            { label: "Manga", href: "/search?q=action manga" },
            { label: "Manhwa", href: "/search?q=manhwa romance" },
            { label: "Manhua", href: "/search?q=manhua cultivation" },
          ].map(chip => (
            <Link
              key={chip.href}
              href={chip.href}
              style={{ flexShrink: 0, fontSize: 12, padding: "7px 14px", borderRadius: 20, background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.08)", color: "#9ca3af", textDecoration: "none", whiteSpace: "nowrap" }}
            >
              {chip.label}
            </Link>
          ))}
        </div>

        {/* Update Terbaru */}
        <section style={{ marginBottom: 32 }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
            <h2 style={{ fontSize: 15, fontWeight: 700, color: "white", margin: 0, display: "flex", alignItems: "center", gap: 8 }}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#f59e0b" strokeWidth="2.5" strokeLinecap="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
              Update Terbaru
            </h2>
            <Link href="/search?sort=latestUploadedChapter" style={{ fontSize: 12, color: "#f59e0b", textDecoration: "none" }}>Lihat semua →</Link>
          </div>
          <div className="manga-grid">
            {latest.map(m => <MangaCard key={m.id} manga={m} />)}
          </div>
        </section>

        {/* Paling Populer */}
        <section>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
            <h2 style={{ fontSize: 15, fontWeight: 700, color: "white", margin: 0, display: "flex", alignItems: "center", gap: 8 }}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="#f59e0b"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 14.5v-9l6 4.5-6 4.5z"/></svg>
              Paling Populer
            </h2>
            <Link href="/search?sort=followedCount" style={{ fontSize: 12, color: "#f59e0b", textDecoration: "none" }}>Lihat semua →</Link>
          </div>
          <div className="manga-grid">
            {popular.map(m => <MangaCard key={m.id} manga={m} />)}
          </div>
        </section>
      </div>
    </div>
  );
}
